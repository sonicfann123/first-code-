# Early 90s Style Rhythm Game — "SONIC Showdown"

This is a small retro-styled rhythm game demo built with HTML/CSS/JavaScript.

How to run
1. Clone or download the files into a folder.
2. Open `index.html` in a modern browser (Chrome, Firefox, Edge).
3. Click "Start Game" or press Space to begin (audio needs a user gesture).

Controls
- Arrow keys (← ↑ → ↓) to hit notes in the 4 lanes.
- Space to start/pause.
- R to restart.

Gameplay
- Notes fall down 4 lanes. Hit a note when it overlaps the hit zone.
- The opponent ("SONIC") animates and reacts to your score.
- Score, combo, accuracy shown at top.

Notes
- All audio is synthesized using the WebAudio API for a chiptune feel.
- This is a fan-made demo using the character name "SONIC" as an opponent.