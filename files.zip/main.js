// Retro rhythm demo — single file game logic
// Controls: Arrow keys to hit notes. Space to start/pause. R to restart.

(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const startBtn = document.getElementById('startBtn');
  const scoreEl = document.getElementById('score');
  const comboEl = document.getElementById('combo');
  const accEl = document.getElementById('accuracy');
  const overlay = document.getElementById('overlay');

  // Game resolution (low-res look)
  const W = 320, H = 240;
  canvas.width = W; canvas.height = H;

  const lanes = 4;
  const laneWidth = W / lanes;
  const hitY = H - 40;

  // Game state
  let audioCtx = null;
  let running = false;
  let startTime = 0;
  let pausedAt = 0;
  let t = 0;
  let notes = [];
  let bpm = 120;
  let beatLength = 60 / bpm;
  let songLength = 30; // seconds
  let score = 0;
  let combo = 0;
  let hits = 0;
  let attempts = 0;

  // simple beatmap: array of {time, lane}
  function generateBeatmap() {
    const map = [];
    const measures = Math.floor(songLength / 4 / beatLength);
    for (let i = 0; i < songLength / beatLength; i++) {
      const time = i * beatLength;
      // pattern: alternating lanes with some variation
      const pattern = [0, 1, 2, 3];
      const lane = pattern[i % 4];
      map.push({time, lane});
      // occasional double
      if (Math.random() < 0.08 && i < (songLength/beatLength)-1) {
        map.push({time: time + beatLength/2, lane: (lane+1)%4});
      }
    }
    return map;
  }

  function resetGame() {
    notes = generateBeatmap();
    score = 0; combo = 0; hits = 0; attempts = 0;
    startTime = 0; pausedAt = 0; running = false;
    updateHUD();
  }

  function updateHUD() {
    scoreEl.textContent = `Score: ${score}`;
    comboEl.textContent = `Combo: ${combo}`;
    const accuracy = attempts ? Math.round((hits/attempts)*100) : 0;
    accEl.textContent = `Accuracy: ${accuracy}%`;
  }

  // Audio helpers (basic chiptune)
  function ensureAudio() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
  }

  function playNote(freq, when=0, dur=0.12, type='square', gain=0.1) {
    ensureAudio();
    const t = audioCtx.currentTime + when;
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(audioCtx.destination);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  // background loop (simple arpeggio)
  let bgOscTimer = null;
  function startBackground() {
    if (!audioCtx) return;
    let idx = 0;
    bgOscTimer = setInterval(() => {
      const freqs = [440, 523.25, 659.25, 784];
      playNote(freqs[idx % freqs.length], 0, 0.16, 'sawtooth', 0.02);
      idx++;
    }, 300);
  }
  function stopBackground() {
    if (bgOscTimer) clearInterval(bgOscTimer);
    bgOscTimer = null;
  }

  // Timing: keep a high-resolution clock synced to audio context for accuracy
  function now() {
    if (!audioCtx) return performance.now()/1000;
    return audioCtx.currentTime;
  }

  // Input handling
  const keyMap = {
    'ArrowLeft': 0,
    'ArrowUp': 1,
    'ArrowRight': 2,
    'ArrowDown': 3
  };

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
      e.preventDefault();
      togglePlay();
      return;
    }
    if (e.key.toLowerCase() === 'r') { restart(); return; }
    if (keyMap.hasOwnProperty(e.key)) {
      handleHit(keyMap[e.key]);
    }
  });

  function handleHit(lane) {
    attempts++;
    // find closest note in lane within hit window (0.2s)
    const current = getSongTime();
    const window = 0.24;
    let bestIdx = -1;
    let bestDelta = window;
    for (let i = 0; i < notes.length; i++) {
      const n = notes[i];
      if (n.lane !== lane || n.hit) continue;
      const delta = Math.abs(n.time - current);
      if (delta < bestDelta) { bestDelta = delta; bestIdx = i; }
    }
    if (bestIdx >= 0) {
      const n = notes[bestIdx];
      n.hit = true;
      // scoring
      const quality = bestDelta < 0.06 ? 300 : (bestDelta < 0.12 ? 100 : 50);
      score += quality + combo * 2;
      combo++;
      hits++;
      playNote(1200 - lane*60, 0, 0.10);
      spawnHitFX(lane, quality);
    } else {
      // miss
      combo = 0;
      playNote(120, 0, 0.15, 'sine', 0.08);
      spawnMissFX(lane);
    }
    updateHUD();
  }

  // visual effects arrays
  const fx = [];

  function spawnHitFX(lane, quality) {
    fx.push({
      x: laneWidth*lane + laneWidth/2,
      y: hitY,
      life: 0.6,
      color: quality === 300 ? '#7dff7d' : (quality===100 ? '#fff57d' : '#7dd7ff'),
      size: 6 + (combo % 10)
    });
  }
  function spawnMissFX(lane) {
    fx.push({
      x: laneWidth*lane + laneWidth/2,
      y: hitY,
      life: 0.8,
      color: '#ff6f6f',
      size: 10
    });
  }

  // opponent (SONIC) simple behavior
  const opponent = {
    x: W - 68, y: 30,
    mood: 0, // -1 sad, 0 neutral, +1 hype
    anim: 0
  };

  function updateOpponent(dt) {
    // mood depends on accuracy
    const acc = attempts ? (hits/attempts) : 0;
    if (acc > 0.75) opponent.mood = Math.min(1, opponent.mood + dt*0.6);
    else if (acc < 0.45) opponent.mood = Math.max(-1, opponent.mood - dt*0.6);
    else opponent.mood += (0 - opponent.mood) * dt * 0.5;
    opponent.anim += dt*8;
  }

  // drawing
  function draw() {
    // low-res pixel background
    ctx.fillStyle = '#001826';
    ctx.fillRect(0,0,W,H);

    // lanes
    for (let i=0;i
