// Replace the existing drawSonic() in game.js with this function
function drawSonic(){
  const s = sonic;
  ctx.save();
  ctx.translate(s.x, s.y);

  // shadow
  ctx.fillStyle = '#00000055';
  ctx.fillRect(-28, 52, 56, 8);

  // spikes (clear, layered quills)
  ctx.fillStyle = palette.sonicBlue;
  // back quills (large)
  const quills = [
    {x:-8, y:-10, x2:-28, y2:-22},
    {x:-2, y:-6, x2:-18, y2:-28},
    {x:6,  y:-8, x2:-6,  y2:-30},
    {x:18, y:-4, x2:6,   y2:-18},
    {x:26, y:2,  x2:10,  y2:-6}
  ];
  quills.forEach(q=>{
    ctx.beginPath();
    ctx.moveTo(q.x, q.y);
    ctx.lineTo(q.x2, q.y2);
    ctx.lineTo(q.x2 + 6, q.y2 + 10);
    ctx.closePath();
    ctx.fill();
  });

  // head/body
  ctx.fillStyle = palette.sonicBlue;
  ctx.beginPath();
  ctx.ellipse(6, -6, 20, 16, 0, 0, Math.PI*2); // head
  ctx.fill();

  // muzzle / face tan
  ctx.fillStyle = '#ffe2b0';
  ctx.beginPath();
  ctx.ellipse(14, -2, 8, 9, 0, 0, Math.PI*2);
  ctx.fill();

  // chest patch
  ctx.beginPath();
  ctx.ellipse(2, 8, 12, 8, 0, 0, Math.PI*2);
  ctx.fill();

  // eye (white + green iris) - gives more Sonic-like look
  ctx.fillStyle = '#fff';
  ctx.beginPath();
  ctx.ellipse(10, -6, 6, 6, 0, 0, Math.PI*2);
  ctx.fill();
  ctx.fillStyle = '#4caf50'; // green iris
  ctx.beginPath();
  ctx.ellipse(11, -5, 3, 3.5, 0, 0, Math.PI*2);
  ctx.fill();
  ctx.fillStyle = '#000';
  ctx.fillRect(12, -6, 2, 4); // small pupil/shade

  // nose
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(8, -2, 2.5, 1.8, 0, 0, Math.PI*2);
  ctx.fill();

  // mouth line
  ctx.strokeStyle = '#2b2b2b';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(16, 0);
  ctx.quadraticCurveTo(10, 4, 2, 6);
  ctx.stroke();

  // gloves (simplified)
  ctx.fillStyle = '#fff';
  // left glove
  ctx.beginPath();
  ctx.ellipse(-6, 26, 7, 7, 0, 0, Math.PI*2);
  ctx.fill();
  // right glove
  ctx.beginPath();
  ctx.ellipse(14, 30, 8, 7, 0, 0, Math.PI*2);
  ctx.fill();

  // shoes: red with white strap
  ctx.fillStyle = '#c62828'; // red shoe
  ctx.fillRect(-12, 36, 28, 10);
  // white strap
  ctx.fillStyle = '#fff';
  ctx.fillRect(-4, 36, 16, 4);
  // shoe sole
  ctx.fillStyle = '#442200';
  ctx.fillRect(-12, 44, 28, 4);

  // slight taunt text/flare
  if(s.tauntTimer > 0){
    ctx.fillStyle = '#fff';
    ctx.font = '10px monospace';
    ctx.fillText("SONIC!", -6, -30);
    s.tauntTimer -= 0.02;
  }

  ctx.restore();
}